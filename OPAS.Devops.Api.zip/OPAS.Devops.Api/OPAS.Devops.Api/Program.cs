﻿using Microsoft.Extensions.Configuration;
using OPAS.Devops.Api.SimpleModels;
using OPAS.Devops.Api.Utlity;
using System;
using System.IO;

namespace OPAS.Devops.Api
{
    class Program
    {
        public static DevopsReleaseModel _devopsRelease = new DevopsReleaseModel();
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
                            .SetBasePath(Directory.GetCurrentDirectory())
                            .AddJsonFile($"appsettings.{"local"}.json", optional: true, reloadOnChange: true);
            var configuration = builder.Build();

            _devopsRelease = configuration.GetSection("DevopsRelease").Get<DevopsReleaseModel>();

            //Console.Write("Enter Azure DevOps Release Type (yaml-1,classic -2: ");

            if (_devopsRelease != null)
            {
                #region "Test Methods for  azure devops ymal  pipeline  using REST API"
                //YamlPipelineHelper.GetProjects();
                YamlPipelineHelper.GetFeedAPI(_devopsRelease);
                //YamlPipelineHelper.GetFeedsAPI(_devopsRelease);
                //YamlPipelineHelper.UpdateFeedAPI(_devopsRelease);
                //YamlPipelineHelper.RunPipeline(_devopsRelease);
                //YamlPipelineHelper.GetAllPipelines(_devopsRelease);
                //YamlPipelineHelper.GetPublishedArtifacts(_devopsRelease);
                #endregion

                #region "Test Methods for  azure devops ymal  pipeline  using SDK"
                //var output=YamlPipelineHelper.SDK_RunPipeline(_devopsRelease);
                //var results= output.Result;

                //YamlPipelineHelper.GetPiplineDefinitionId(_devopsRelease);

                //YamlPipelineHelper.GetLatestPiplineBuildId(_devopsRelease);

                //var output = YamlPipelineHelper.SDK_GetPublishedArtifacts(_devopsRelease);
                //var results = output.Result;

                //var output = YamlPipelineHelper.GeYmlBuild(_devopsRelease);
                //var results = output.Result;

                //var output = YamlPipelineHelper.GetAllYmlBuilds(_devopsRelease);
                //var results = output.Result;

                //not downloading zip file
                //YamlPipelineHelper.GetArtifactContentZip(_devopsRelease);
                YamlPipelineHelper.SDK_UpdateRunPipeline(_devopsRelease);

                #endregion

                #region "Test Methods for azure devops classic pipeline"
                //ClassicPipelineHelper.CreateTriggerRelease(_devopsRelease);

                //ClassicPipelineHelper.GetArtifactVersions(_devopsRelease);

                //var res = ClassicPipelineHelper.GetAllReleaseDetail(_devopsRelease);
                //var output = res.Result;

                //var res = ClassicPipelineHelper.GetReleaseDetail(_devopsRelease);
                //var output = res.Result;

                //var res = ClassicPipelineHelper.GetAllArtifactVersions(_devopsRelease);
                //var output = res.Result;

                //var res = ClassicPipelineHelper.GetArtifactVersions(_devopsRelease);
                //var output = res.Result;

                //ClassicPipelineHelper.GetReleaseChangeDetails(_devopsRelease);

                //ClassicPipelineHelper.GetReleaseDefinitionHistory(_devopsRelease);
                #endregion

                //var outputQueryOpenBugs = QueryExecutor.QueryOpenBugs(_devopsRelease.DevopsTeamProject);
                //var outputQueryOpenBugResult = outputQueryOpenBugs.Result;
                //var outputPrintOpenBugs = QueryExecutor.PrintOpenBugsAsync(_devopsRelease.DevopsTeamProject);
            }
            Console.ReadKey();
        }



    }
}
