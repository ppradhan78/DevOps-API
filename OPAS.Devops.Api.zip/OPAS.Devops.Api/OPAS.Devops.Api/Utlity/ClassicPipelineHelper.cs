﻿using Microsoft.TeamFoundation.Core.WebApi;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.VisualStudio.Services.ReleaseManagement.WebApi;
using Microsoft.VisualStudio.Services.ReleaseManagement.WebApi.Clients;
using Microsoft.VisualStudio.Services.ReleaseManagement.WebApi.Contracts;
using Microsoft.VisualStudio.Services.WebApi;
using OPAS.Devops.Api.SimpleModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OPAS.Devops.Api.Utlity
{
    public static class ClassicPipelineHelper
    {
        /// <summary>
        /// Trigger the pipline Classic for configure environment.
        /// Trigger the pipline Classic for configure environment & Artifacts .
        /// </summary>
        /// <param name="input"></param>
        public static void CreateTriggerRelease(DevopsReleaseModel input)
        {
            Uri orgDevopsUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgDevopsUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));

            var releaseClient = connection.GetClient<ReleaseHttpClient>();

            //Get All the Release Definition
            var releases = releaseClient.GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments).Result.ToArray();
            //Filter the Release Definition
            var release = releases.FirstOrDefault(x => x.Name.ToLower() == input.ApplicationName.ToLower());

            if (release != null)
            {
                var getRelease = releaseClient.GetReleaseDefinitionAsync(input.DevopsTeamProject, release.Id);
                var newRease = new Release();
                newRease.Id = release.Id;
                IList<ArtifactMetadata> artifacts = new List<ArtifactMetadata>();
                //Get the production Artifact version specified  in json file.
                if (input.IsProductionArtifact)
                {
                    foreach (var item in input.ProductionArtifacts)
                    {
                        ArtifactMetadata artifact = new ArtifactMetadata()
                        {
                            Alias = item.Name,
                            InstanceReference = new BuildVersion() { Id = item.Version },
                        };
                        artifacts.Add(artifact);
                    }
                }
                else
                {
                    //Get the latest Artifact 
                    var ArtifactVersions = releaseClient.GetArtifactVersionsAsync(input.DevopsTeamProject, release.Id).Result;
                    foreach (var item in ArtifactVersions?.ArtifactVersions)
                    {
                        ArtifactMetadata artifact = new ArtifactMetadata()
                        {
                            Alias = item.Alias,
                            InstanceReference = new BuildVersion() { Id = item.DefaultVersion.Id },
                        };
                        artifacts.Add(artifact);
                    }
                }
                ReleaseStartMetadata releaseStartMetadata = new ReleaseStartMetadata()
                {
                    DefinitionId = release.Id,
                    Artifacts = artifacts,
                };
                //Create release
                var resultCreateRelease = releaseClient.CreateReleaseAsync(releaseStartMetadata, input.DevopsTeamProject).Result;
                //Trigger the release
                resultCreateRelease.Environments = resultCreateRelease.Environments.Where(x => GetAllEnvoriment(input.ManualEnvironments).Contains(x.Name.ToLower())).ToList();
                var environmentUpdate = new ReleaseEnvironmentUpdateMetadata()
                {
                    Status = EnvironmentStatus.InProgress
                };
                for (int i = 0; i < resultCreateRelease.Environments.Count; i++)
                {
                    resultCreateRelease.Environments[i] = releaseClient.UpdateReleaseEnvironmentAsync(environmentUpdate, input.DevopsTeamProject, resultCreateRelease.Id, resultCreateRelease.Environments[i].Id).Result;
                }
            }
        }
        /// <summary>
        /// Get All Artifact Versions
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static Task<ArtifactVersionQueryResult> GetAllArtifactVersions(DevopsReleaseModel input)
        {
            Task<ArtifactVersionQueryResult> _task = null;
            Uri orgUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
            var releaseClient = connection.GetClient<ReleaseHttpClient>();
            var releases = releaseClient.GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments)
                    .Result.ToArray();
            foreach (var release in releases)
            {
                if (release.Name.ToLower() == input.ApplicationName.ToLower())
                {
                    _task = releaseClient.GetArtifactVersionsAsync(input.DevopsTeamProject, release.Id);
                }
            }
            return _task;
        }
        /// <summary>
        /// Get Artifact Versions
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static Task<ArtifactVersionQueryResult> GetArtifactVersions(DevopsReleaseModel input)
        {
            Task<ArtifactVersionQueryResult> _task = null;
            Uri orgUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
            var releaseClient = connection.GetClient<ReleaseHttpClient>();
            var releases = releaseClient.GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments)
                    .Result.ToArray();

            var release = releases.FirstOrDefault(x => x.Name.ToLower() == input.ApplicationName.ToLower());
            _task = releaseClient.GetArtifactVersionsAsync(input.DevopsTeamProject, release.Id);
            return _task;
        }
        /// <summary>
        /// Get All Release Detail
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<List<ReleaseDefinition>> GetAllReleaseDetail(DevopsReleaseModel input)
        {
            Uri orgUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
            var releaseClient = connection.GetClient<ReleaseHttpClient>();
            var Allrelease = await releaseClient
                       .GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments);
            return Allrelease;
        }
        /// <summary>
        ///  Get Release Detail
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<ReleaseDefinition> GetReleaseDetail(DevopsReleaseModel input)
        {
            Uri orgUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
            var releaseClient = connection.GetClient<ReleaseHttpClient>();
            var Allrelease = await releaseClient
                       .GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments);
            var release = Allrelease.FirstOrDefault(x => x.Name.ToLower() == input.ApplicationName.ToLower());
            return release;
        }
        /// <summary>
        /// Get Release Change Details
        /// </summary>
        /// <param name="input"></param>
        public static void GetReleaseChangeDetails(DevopsReleaseModel input)
        {
            Uri orgUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
            var releaseClient = connection.GetClient<ReleaseHttpClient>();
            var releases = releaseClient
                    .GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments)
                    .Result.ToArray();
            var release = releases.FirstOrDefault(x => x.Name.ToLower() == input.ApplicationName.ToLower());

            var r = releaseClient.GetReleaseDefinitionAsync(input.DevopsTeamProject, release.Id);
            var output = r.Result;
            //Get all the release 
            var Allreleases = releaseClient.GetReleasesAsync(input.DevopsTeamProject, release.Id).Result;
            var releaseDeployee = Allreleases.Where(x => x.Name == input.ReleaseNumber);
            foreach (var rele in releaseDeployee)
            {
                var releaseChanges = releaseClient.GetReleaseChangesAsync(input.DevopsTeamProject, rele.Id);
                var releaseChangesOut = releaseChanges.Result;
            }

        }
        /// <summary>
        /// Get Release Definition History
        /// </summary>
        /// <param name="input"></param>
        public static void GetReleaseDefinitionHistory(DevopsReleaseModel input)
        {
            Uri orgUrl = new Uri(input.DevopsUrl);
            VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
            var releaseClient = connection.GetClient<ReleaseHttpClient>();

            var projectClient = connection.GetClient<ProjectHttpClient>();
            var project = projectClient.GetProject(input.DevopsTeamProject).Result;
            Console.WriteLine(project.Name);

            var releases = releaseClient
                    .GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments)
                    .Result.ToArray();
            var release = releases.FirstOrDefault(x => x.Name.ToLower() == input.ApplicationName.ToLower());
            var rh = releaseClient.GetReleaseDefinitionHistoryAsync(input.DevopsTeamProject, release.Id);
            var outputh = rh.Result;
            var histry = outputh.FindLast(x => x.ChangedDate.Date.ToShortDateString() == input.LatestArtifactDate);
        }
        private static IList<string> GetAllEnvoriment(string envoriments)
        {
            string[] envs = envoriments.Split(",");
            IList<string> env = new List<string>();
            foreach (var item in envs)
            {
                env.Add(item.ToLower());
            }
            return env;
        }
        //public static void GetReleaseDetail(DevopsReleaseModel input)
        //{
        //    Uri orgUrl = new Uri(input.DevopsUrl);
        //    VssConnection connection = new VssConnection(orgUrl, new VssBasicCredential(string.Empty, input.PersonalAccessToken));
        //    var releaseClient = connection.GetClient<ReleaseHttpClient>();

        //    var projectClient = connection.GetClient<ProjectHttpClient>();
        //    var project = projectClient.GetProject(input.DevopsTeamProject).Result;

        //    var Allrelease = releaseClient
        //            .GetReleaseDefinitionsAsync(input.DevopsTeamProject, string.Empty, ReleaseDefinitionExpands.Environments)
        //            .Result.ToArray();

        //    foreach (var release in Allrelease)
        //    {
        //        if (release.Name.ToLower() == input.ApplicationName.ToLower())
        //        {
        //            var r = releaseClient.GetReleaseDefinitionAsync(input.DevopsTeamProject, release.Id);
        //            var output = r.Result;
        //            //Get all the release 
        //            var Allrelease = releaseClient.GetReleasesAsync(input.DevopsTeamProject, release.Id).Result;
        //            //Find the Prod release based on Release Name
        //            var releaseDeployee = Allrelease.Where(x => x.Name == input.ReleaseNumber);

        //            foreach (var rele in releaseDeployee)
        //            {
        //                var releaseResult = releaseClient.GetReleaseAsync(input.DevopsTeamProject, rele.Id).Result;
        //                foreach (var en in releaseResult.Environments)
        //                {
        //                    Console.WriteLine("Environments " + en.Name + "Status:" + en.Status);
        //                }
        //            }
        //        }
        //    }
        //}
    }
}
