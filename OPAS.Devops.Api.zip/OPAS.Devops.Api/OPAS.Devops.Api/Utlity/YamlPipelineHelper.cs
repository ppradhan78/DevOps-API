﻿using Microsoft.TeamFoundation.Build.WebApi;
using Microsoft.TeamFoundation.Core.WebApi;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.VisualStudio.Services.WebApi;
using Newtonsoft.Json;
using OPAS.Devops.Api.SimpleModels;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace OPAS.Devops.Api.Utlity
{


    public static class YamlPipelineHelper
    {

        #region REST API
        public static async void GetProjects()
        {
            try
            {
                var personalaccesstoken = "ndmpksud6rjbihc42opt4xdjsakwhfaplbgz6xgnp66cqvlexk4a";

                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(
                        new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                        Convert.ToBase64String(
                            System.Text.ASCIIEncoding.ASCII.GetBytes(
                                string.Format("{0}:{1}", "", personalaccesstoken))));

                    using (HttpResponseMessage response = await client.GetAsync(
                                 //"https://dev.azure.com/{organization}/_apis/projects"))
                                 "https://dev.azure.com/opasdevops/_apis/projects"))
                    {
                        response.EnsureSuccessStatusCode();
                        string responseBody = await response.Content.ReadAsStringAsync();
                        Console.WriteLine(responseBody);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public static bool GetFeedAPI(DevopsReleaseModel input)
        {
            HttpClient client = new HttpClient();
            var apiUrl = "https://feeds.dev.azure.com/opasdevops/OPAS_Devops/_apis/packaging/feeds/OPAS.Reporting.UI?api-version=6.1-preview.1";
            client.BaseAddress = new Uri(apiUrl);

            string encoded = Convert.ToBase64String(Encoding.GetEncoding("UTF-8").GetBytes(input.UserName + ":" + input.PersonalAccessToken));
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + encoded);

            var inputData = new
            {
            };

            var content = JsonConvert.SerializeObject(inputData);
            var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage resp = client.GetAsync(apiUrl).Result;
            var outputresult = resp.Content.ReadAsStringAsync();
            if (resp != null)
                return resp.IsSuccessStatusCode;
            else
                return false;
        }
        public static bool GetFeedsAPI(DevopsReleaseModel input)
        {
            HttpClient client = new HttpClient();
            var apiUrl = "https://feeds.dev.azure.com/opasdevops/OPAS_Devops/_apis/packaging/feeds?api-version=6.1-preview.1";
            client.BaseAddress = new Uri(apiUrl);

            string encoded = Convert.ToBase64String(Encoding.GetEncoding("UTF-8").GetBytes(input.UserName + ":" + input.PersonalAccessToken));
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + encoded);

            var inputData = new  
            {
              
            };

            var content = JsonConvert.SerializeObject(inputData);
            var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage resp = client.GetAsync(apiUrl).Result;
            var outputresult = resp.Content.ReadAsStringAsync();
            if (resp != null)
                return resp.IsSuccessStatusCode;
            else
                return false;
        }
        public static bool UpdateFeedAPI(DevopsReleaseModel input)
        {
            HttpClient client = new HttpClient();
            var apiUrl = "https://feeds.dev.azure.com/opasdevops/OPAS_Devops/_apis/packaging/feeds/OPAS.AzureInfrastructureOPAS?api-version=6.1-preview.1";
            client.BaseAddress = new Uri(apiUrl);

            string encoded = Convert.ToBase64String(Encoding.GetEncoding("UTF-8").GetBytes(input.UserName + ":" + input.PersonalAccessToken));
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + encoded);

            var inputData = new DevOpsymlParam
            {
                stagesToSkip = GetAllEnvoriment(input.YmlStages),
                PipelineArtifact= "1.1.34085"
            };

            var content = JsonConvert.SerializeObject(inputData);
            var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage resp = client.PatchAsync(apiUrl, stringContent).Result;
            var outputresult = resp.Content.ReadAsStringAsync();
            if (resp != null)
                return resp.IsSuccessStatusCode;
            else
                return false;
        }

        /// <summary>
        ///It will run the ymal pipline for configure environment using ReST API
        /// https://dev.azure.com/{organization}/{project}/_apis/pipelines/{pipelineId}/runs?api-version=6.1-preview.1
        /// </summary>
        /// <param name="input"></param>
        public static bool RunPipeline(DevopsReleaseModel input)
        {
            HttpClient client = new HttpClient();
            var apiUrl = input.DevopsUrl + input.DevopsTeamProject + "/_apis/pipelines/" + input.AppDefinitionId + "/runs?api-version=6.1-preview.1";
            client.BaseAddress = new Uri(apiUrl);

            string encoded = Convert.ToBase64String(Encoding.GetEncoding("UTF-8").GetBytes(input.UserName + ":" + input.PersonalAccessToken));
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + encoded);

            var inputData = new DevOpsymlParam
            {
                stagesToSkip = GetAllEnvoriment(input.YmlStages)
            };

            var content = JsonConvert.SerializeObject(inputData);
            var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage resp = client.PostAsync(apiUrl, stringContent).Result;

            if (resp != null)
                return resp.IsSuccessStatusCode;
            else
                return false;
        }

        /// <summary>
        /// It will return all the ymal piplines details using ReST API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static PipelinesOutputModel GetAllPipelines(DevopsReleaseModel input)
        {
            HttpClient client = new HttpClient();
            var apiUrl = input.DevopsUrl + input.DevopsTeamProject + "/_apis/pipelines?api-version=6.1-preview.1";
            client.BaseAddress = new Uri(apiUrl);

            string encoded = Convert.ToBase64String(Encoding.GetEncoding("UTF-8").GetBytes(input.UserName + ":" + input.PersonalAccessToken));
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + encoded);

            var inputData = new
            {
            };
            var myContent = JsonConvert.SerializeObject(inputData);
            var stringContent = new StringContent(myContent, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage resp = client.GetAsync(apiUrl).Result;
            var outputresult = resp.Content.ReadAsStringAsync();

            if (resp != null && resp.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<PipelinesOutputModel>(outputresult.Result);
            else
                return null;

        }

        /// <summary>
        /// It will return all the Published Artifacts ymal piplines details using REST API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static List<PipelineOutputModel> GetPublishedArtifacts(DevopsReleaseModel input)
        {
            var PublishedArtifacts = new List<PipelineOutputModel>();


            int PipelinesId = GetPiplineDefinitionId(input);
            int RunId = GetLatestPiplineBuildId(input);
            foreach (var artifactName in input.PublishedArtifacts.Split(','))
            {
                HttpClient client = new HttpClient();

                var apiUrl = input.DevopsUrl + input.DevopsTeamProject + "/_apis/pipelines/" + PipelinesId + "/runs/" + RunId + "/artifacts?artifactName=" + artifactName + "&api-version=6.1-preview.1";
                client.BaseAddress = new Uri(apiUrl);
                string username = "ppradha7";
                string password = input.PersonalAccessToken;

                string encoded = Convert.ToBase64String(Encoding.GetEncoding("UTF-8").GetBytes(username + ":" + password));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + encoded);

                var inputData = new
                {

                };
                var content = JsonConvert.SerializeObject(inputData);
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage resp = client.GetAsync(apiUrl).Result;
                var outputresult = resp.Content.ReadAsStringAsync();
                if (resp != null && resp.IsSuccessStatusCode)
                    PublishedArtifacts.Add(JsonConvert.DeserializeObject<PipelineOutputModel>(outputresult.Result));

                client.Dispose();
            }

            return PublishedArtifacts;

        }

        #endregion

        #region SKD
        /// <summary>
        ///It will run the ymal pipline
        /// https://dev.azure.com/{organization}/{project}/_apis/pipelines/{pipelineId}/runs?api-version=6.1-preview.1
        /// </summary>
        /// <param name="input"></param>
        public static async Task<Build> SDK_RunPipeline(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            var projectClient = connection.GetClient<ProjectHttpClient>();
            var project = projectClient.GetProject(input.DevopsTeamProject).Result;

            var definition = buildClient.GetDefinitionAsync(input.DevopsTeamProject, input.AppDefinitionId).Result;
            var Environment = new Dictionary<string, string> { { "stagesToSkip", "deploy_dev" } };

            var build = new Build()
            {
                Definition = definition,
                Project = project,
                Parameters = JsonConvert.SerializeObject(Environment)
            };

            //build.TriggerInfo
            return await buildClient.QueueBuildAsync(build);
        }
        public static async Task<Build> SDK_UpdateRunPipeline(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            var projectClient = connection.GetClient<ProjectHttpClient>();
            var project = projectClient.GetProject(input.DevopsTeamProject).Result;

            var definition = buildClient.GetDefinitionAsync(input.DevopsTeamProject, input.AppDefinitionId).Result;
            var Environment = new Dictionary<string, string> { { "stagesToSkip", "deploy_dev" } };

            var build = new Build()
            {
                Definition = definition,
                Project = project,
                Parameters = JsonConvert.SerializeObject(Environment),
            };

         
            //build.TriggerInfo
            return await buildClient.UpdateBuildAsync(build);
        }

        /// <summary>
        /// Get the DefinitionId
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static int GetPiplineDefinitionId(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            var GetDefinitions = buildClient.GetDefinitionsAsync(input.DevopsTeamProject);
            var outputGetBuilds = GetDefinitions.Result;
            var projectname = outputGetBuilds.Find(x => x.Name == input.ApplicationName);
            return projectname.Id;
        }
        /// <summary>
        /// Get Latest BuildId
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static int GetLatestPiplineBuildId(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            var build = buildClient.GetBuildsAsync(input.DevopsTeamProject);
            var outbuild = build.Result;
            var projectBuild = outbuild.Find(x => x.Definition.Name == input.ApplicationName);

            return projectBuild.Id;
        }
        public static async Task<List<BuildArtifact>> SDK_GetPublishedArtifacts(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            int BuildId = GetLatestPiplineBuildId(input);
            return await buildClient.GetArtifactsAsync(input.DevopsTeamProject, BuildId);
        }

        /// <summary>
        /// Get Build details
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<Build> GeYmlBuild(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            int buildId = GetLatestPiplineBuildId(input);
            var build = await buildClient.GetBuildAsync(input.DevopsTeamProject, buildId);

            var outputGetBuild = build.Result;
            return build;
        }
        /// <summary>
        /// Get all Build details
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<List<Build>> GetAllYmlBuilds(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClient>();

            return await buildClient.GetBuildsAsync(input.DevopsTeamProject);
        }
        public static void GetArtifactContentZip(DevopsReleaseModel input)
        {
            try
            {
                var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
                var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
                var BuildClient = connection.GetClient<BuildHttpClient>();
                int buildId = GetLatestPiplineBuildId(input);
                BuildClient.GetArtifactContentZipAsync(input.DevopsTeamProject, buildId, "releasetoolsscripts").ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
                if (ex.InnerException != null) Console.WriteLine("Detailed Info: " + ex.InnerException.Message);
                Console.WriteLine("Stack:\n" + ex.StackTrace);
            }
        }


        #endregion

        /// <summary>
        /// Get the Envoriments
        /// </summary>
        /// <param name="envoriments"></param>
        /// <returns></returns>
        private static List<string> GetAllEnvoriment(string envoriments)
        {
            string[] envs = envoriments.Split(",");
            List<string> env = new List<string>();
            foreach (var item in envs)
            {
                env.Add(item.ToLower());
            }
            return env;
        }
        public static void test(DevopsReleaseModel input)
        {
            var credential = new VssBasicCredential(string.Empty, input.PersonalAccessToken);
            var connection = new VssConnection(new Uri(input.DevopsUrl), credential);
            var buildClient = connection.GetClient<BuildHttpClientBase>();
            int id = GetLatestPiplineBuildId(input);

            //var GetArtifact = buildClient.GetArtifactAsync(input.DevopsTeamProject, id, "releasetoolsscripts");
            //var outputGetArtifact = GetArtifact.Result;


            //var GetArtifact1 = buildClient.GetArtifactsAsync(input.DevopsTeamProject, id);
            //var outputGetArtifact1 = GetArtifact1.Result;


            //var tokenSource2 = new CancellationTokenSource();
            //CancellationToken ct = tokenSource2.Token;
            //var GetDefinitions1 = buildClient.GetDefinitionsAsync2(input.DevopsTeamProject,null,null,null,null,null,null,null,null,null,null,null,null, ct);
            //var outputGetBuilds1 = GetDefinitions.Result;
            //var projectname1 = outputGetBuilds.FirstOrDefault(x => x.Name == "Reporting.Service");

            //var tokenSource1 = new CancellationTokenSource();
            //CancellationToken ct1 = tokenSource1.Token;
            //var GetDefinitions2 = buildClient.GetFullDefinitionsAsync(input.DevopsTeamProject, null, null, null, null, null, null, null, null, null, null, null, null, ct1);
            //var outputGetBuilds2 = GetDefinitions2.Result;
            //var projectname2 = outputGetBuilds2.FirstOrDefault(x => x.Name == "Reporting.Service");
        }

    }
}
