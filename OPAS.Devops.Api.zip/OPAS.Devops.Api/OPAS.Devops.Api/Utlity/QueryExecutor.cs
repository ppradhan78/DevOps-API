﻿using Microsoft.TeamFoundation.WorkItemTracking.WebApi;
using Microsoft.TeamFoundation.WorkItemTracking.WebApi.Models;
using Microsoft.VisualStudio.Services.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OPAS.Devops.Api.Utlity
{
    public static class QueryExecutor
    {
        private static readonly string uri= "https://dev.azure.com/opasdevops/";
        private static readonly string personalAccessToken= "ndmpksud6rjbihc42opt4xdjsakwhfaplbgz6xgnp66cqvlexk4a";


        /// <summary>
        ///     Execute a WIQL (Work Item Query Language) query to return a list of open bugs.
        /// </summary>
        /// <param name="project">The name of your project within your organization.</param>
        /// <returns>A list of <see cref="WorkItem"/> objects representing all the open bugs.</returns>
        public static async Task<IList<WorkItem>> QueryOpenBugs(string project)
        {
            var credentials = new VssBasicCredential(string.Empty, personalAccessToken);

            // create a wiql object and build our query
            var wiql = new Wiql()
            {
                // NOTE: Even if other columns are specified, only the ID & URL will be available in the WorkItemReference
                Query = "Select [Id] " +
                        "From WorkItems " +
                        "Where [Work Item Type] = 'Bug' " +
                        "And [System.TeamProject] = '" + project + "' " +
                        "And [System.State] <> 'Closed' " +
                        "Order By [State] Asc, [Changed Date] Desc",
            };

            // create instance of work item tracking http client
            using (var httpClient = new WorkItemTrackingHttpClient(new Uri(uri), credentials))
            {
                // execute the query to get the list of work items in the results
                var result = await httpClient.QueryByWiqlAsync(wiql).ConfigureAwait(false);
                var ids = result.WorkItems.Select(item => item.Id).ToArray();

                // some error handling
                if (ids.Length == 0)
                {
                    return Array.Empty<WorkItem>();
                }

                // build a list of the fields we want to see
                var fields = new[] { "System.Id", "System.Title", "System.State" };

                // get work items for the ids found in query
                return await httpClient.GetWorkItemsAsync(ids, fields, result.AsOf).ConfigureAwait(false);
            }
        }

        /// <summary>
        ///     Execute a WIQL (Work Item Query Language) query to print a list of open bugs.
        /// </summary>
        /// <param name="project">The name of your project within your organization.</param>
        /// <returns>An async task.</returns>
        public static async Task PrintOpenBugsAsync(string project)
        {
            var workItems = await QueryOpenBugs(project).ConfigureAwait(false);

            Console.WriteLine("Query Results: {0} items found", workItems.Count);

            // loop though work items and write to console
            foreach (var workItem in workItems)
            {
                Console.WriteLine(
                    "{0}\t{1}\t{2}",
                    workItem.Id,
                    workItem.Fields["System.Title"],
                    workItem.Fields["System.State"]);
            }
        }
    }
}
// nuget:Microsoft.TeamFoundationServer.Client


