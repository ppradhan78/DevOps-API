﻿namespace OPAS.Devops.Api.SimpleModels
{
    public class PipelineOutputModel
    {
        public string name { get; set; }
        public string url { get; set; }

    }
}
