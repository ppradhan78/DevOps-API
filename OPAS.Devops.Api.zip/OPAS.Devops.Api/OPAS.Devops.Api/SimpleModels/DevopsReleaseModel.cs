﻿using System.Collections.Generic;

namespace OPAS.Devops.Api.SimpleModels
{
    public  class DevopsReleaseModel
    {
        public  string DevopsUrl { get; set; }
        public string UserName { get; set; }
        public  string PersonalAccessToken { get; set; }
        public  string DevopsTeamProject { get; set; }
        public  string ApplicationName { get; set; }
        public  string LatestArtifactDate { get; set; }
        public  string BuildVersionId { get; set; }
        public  string ManualEnvironments { get; set; }
        public bool IsProductionArtifact { get; set; }
        public string ReleaseNumber { get; set; }
        public List<ProductionArtifacts> ProductionArtifacts { get; set; }
        public int AppDefinitionId { get; set; }
        public string YmlStages { get; set; }
        public string PublishedArtifacts { get; set; }
    }
    public class ProductionArtifacts
    {
        public string Name { get; set; }
        public string Version { get; set; }
    }
    public class DevOpsymlParam
    {
        public List<string> stagesToSkip { get; set; }
        public string PipelineArtifact { get; set; }
    }
}
